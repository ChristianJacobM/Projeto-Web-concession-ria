function Cadastro() {
    if ($('#nome').val().length < 0) {
        alert("Preencha todos os campos!"); 
    } 
    else {
        alert("Cadastro efetuado com sucesso!"); 
    }
}