<?php
    $host = "Localhost";
    $usuario = "root";
    $senha = "";
    $bd = "Fabricante";

    $conexao = new mysqli($host, $usuario, $senha, $bd  )

   /*
   if($conexao->connect_errno)
    {
        echo "Erro";
    }
    else
    {
        echo "Conexao efetuada com sucesso";
    }
    */
?>